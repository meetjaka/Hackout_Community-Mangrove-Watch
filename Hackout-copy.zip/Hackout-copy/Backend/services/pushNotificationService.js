const webpush = require('web-push');
const User = require('../models/User');

class PushNotificationService {
  constructor() {
    webpush.setVapidDetails(
      'mailto:' + process.env.VAPID_EMAIL,
      process.env.VAPID_PUBLIC_KEY,
      process.env.VAPID_PRIVATE_KEY
    );
  }

  // Save push subscription for a user
  async saveSubscription(userId, subscription) {
    try {
      await User.findByIdAndUpdate(userId, {
        pushSubscription: subscription
      });
    } catch (error) {
      console.error('Error saving push subscription:', error);
      throw error;
    }
  }

  // Send push notification to a specific user
  async sendToUser(userId, notification) {
    try {
      const user = await User.findById(userId);
      if (!user.pushSubscription) return;

      const payload = JSON.stringify({
        title: notification.title,
        body: notification.body,
        icon: notification.icon || '/icons/logo-192x192.png',
        badge: notification.badge || '/icons/badge-72x72.png',
        data: notification.data || {}
      });

      await webpush.sendNotification(user.pushSubscription, payload);
    } catch (error) {
      console.error('Error sending push notification:', error);
      if (error.statusCode === 410) {
        // Subscription has expired or is invalid
        await User.findByIdAndUpdate(userId, {
          pushSubscription: null
        });
      }
      throw error;
    }
  }

  // Send push notification to multiple users
  async sendToUsers(userIds, notification) {
    const promises = userIds.map(userId => 
      this.sendToUser(userId, notification).catch(err => {
        console.error(`Failed to send notification to user ${userId}:`, err);
        return null;
      })
    );

    return Promise.all(promises);
  }

  // Send notification to users in an area
  async sendToArea(coordinates, radiusKm, notification) {
    try {
      const users = await User.find({
        location: {
          $near: {
            $geometry: {
              type: 'Point',
              coordinates: coordinates
            },
            $maxDistance: radiusKm * 1000
          }
        },
        pushSubscription: { $ne: null }
      });

      return this.sendToUsers(
        users.map(user => user._id),
        notification
      );
    } catch (error) {
      console.error('Error sending area notification:', error);
      throw error;
    }
  }

  // Send notification for new report
  async sendNewReportNotification(report) {
    const notification = {
      title: 'New Mangrove Report',
      body: `New ${report.category} report submitted near your area`,
      data: {
        type: 'NEW_REPORT',
        reportId: report._id
      }
    };

    await this.sendToArea(
      report.location.coordinates,
      10, // 10km radius
      notification
    );
  }

  // Send notification for report verification
  async sendVerificationNotification(report) {
    const notification = {
      title: 'Report Verified',
      body: `Your report on ${report.category} has been verified`,
      data: {
        type: 'REPORT_VERIFIED',
        reportId: report._id
      }
    };

    await this.sendToUser(report.reporter, notification);
  }

  // Send urgent alert notification
  async sendUrgentAlert(alert) {
    const notification = {
      title: '⚠️ Urgent Alert',
      body: alert.message,
      data: {
        type: 'URGENT_ALERT',
        alertId: alert._id
      }
    };

    if (alert.area) {
      await this.sendToArea(
        alert.area.coordinates,
        alert.area.radius,
        notification
      );
    } else {
      const users = await User.find({
        role: { $in: alert.targetRoles },
        pushSubscription: { $ne: null }
      });
      await this.sendToUsers(
        users.map(user => user._id),
        notification
      );
    }
  }
}

module.exports = new PushNotificationService();
